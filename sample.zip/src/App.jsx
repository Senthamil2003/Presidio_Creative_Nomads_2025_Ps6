import "./App.scss";
import Dualcontroller from "./components/dualcontroller/dualcontroller";
import Feature from "./components/feature/Feature";
import Footer from "./components/footer/Footer";
import Games from "./components/games/Games";
import Home from "./components/home/Home";

function App() {
  return (
    <>
      <div className="App">
        <Home />
        <Dualcontroller />
        <Feature />
        <Games />
        <Footer />
      </div>
    </>
  );
}

export default App;
