import logo from "../../assets/images/logo.png";
import pay from "../../assets/images/Pay.png";
import Button from "../reusables/Button";
import dpay from "../../assets/images/Pay (1).png";
import "./Nav.scss";
export default function Nav() {
  return (
    <div>
      <ul className="nav-cont">
        <div className="logo-cont">
          <img src={logo} className="logo-cont" alt="logo" />
        </div>

        <div className="nav-menu">
          <ul className="nav-item">Playstation 6</ul>
          <ul className="nav-item">Features</ul>
          <ul className="nav-item">Games</ul>
          <ul className="nav-item">Accessories</ul>
          <ul className="nav-item">Contact</ul>
        </div>
        <div>
          <Button content="PRE BOOK" img={pay} dimg={dpay} />
        </div>
      </ul>
    </div>
  );
}
