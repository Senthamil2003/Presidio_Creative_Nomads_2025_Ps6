// import Button from "../reusables/Button";
import GameBanner from "../reusables/GameBanner";
import GameIconContainer from "./GameIconContainer";
import "./Games.scss";

import topimg1 from "../../assets/images/topimg1.png";
import topimg2 from "../../assets/images/topimg2.png";
import topimg3 from "../../assets/images/topimg3.png";
import topimg4 from "../../assets/images/topimg4.png";
import topimg5 from "../../assets/images/topimg5.png";
import topimg6 from "../../assets/images/topimg6.png";
import bottomimg1 from "../../assets/images/bottomimg1.png";
import bottomimg2 from "../../assets/images/bottomimg2.png";
import bottomimg3 from "../../assets/images/bottomimg3.png";
import bottomimg4 from "../../assets/images/bottomimg4.png";
import bottomimg5 from "../../assets/images/bottomimg5.png";
import bottomimg6 from "../../assets/images/bottomimg6.png";
import { useState } from "react";
export default function Games() {
  const [topimg, setTopimg] = useState(topimg1);
  const [bottomimg, setBottomimg] = useState(bottomimg1);
  const imageObject = {
    1: [topimg1, bottomimg1],
    2: [topimg2, bottomimg2],
    3: [topimg3, bottomimg3],
    4: [topimg4, bottomimg4],
    5: [topimg5, bottomimg5],
    6: [topimg6, bottomimg6],
  };
  const changeImage = (value) => {
    setTopimg(imageObject[value][0]);
    setBottomimg(imageObject[value][1]);
  };

  return (
    <div className="games-tot-cont">
      <GameBanner topimg={topimg} bottomimg={bottomimg} />
      <div className="games-content-cont">
        <p className="head-content">Play Your Way !</p>

        <p className="h2-content">
          Embark on Epic Adventures, Conquer New Worlds, and Redefine Your
          Gaming Journey with PS6 Exclusive Titles and Enhanced Classics
        </p>
        <GameIconContainer changeImage={changeImage} />

        {/* <Button content="View All Games" img="images/arrow.png" dimg="images/arrow.png" /> */}
      </div>
    </div>
  );
}
