// eslint-disable-next-line react/prop-types
export default function GameBanner({ topimg, bottomimg }) {
  return (
    <div className="game-banner-tot-cont">
      <div className="top-banner-img">
        <img src={topimg} alt="" />
      </div>
      <div className="bottom-banner-img">
        <img src={bottomimg} alt="" />
      </div>
    </div>
  );
}
