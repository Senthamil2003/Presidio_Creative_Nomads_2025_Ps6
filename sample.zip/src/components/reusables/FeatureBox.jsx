
import PropTypes from "prop-types";
export default function FeatureBox({ img, content, width, changeIndex, index }) {
  return (
    <div
      className="feature-box-cont"
      style={{ width: `${width}%` }}
      onMouseEnter={() => changeIndex(index)}
    >
      <img src={img} alt={content} />
      <p className="small-head-content">{content}</p>
    </div>
  );
}

FeatureBox.propTypes = {
  img: PropTypes.string.isRequired,
  content: PropTypes.string.isRequired,
  width: PropTypes.number.isRequired,
  changeIndex: PropTypes.func.isRequired,
  index: PropTypes.number.isRequired,
};
