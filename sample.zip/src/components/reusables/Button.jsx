import { useState } from "react";

// eslint-disable-next-line react/prop-types
export default function Button({ content, img, dimg }) {
  const [isHovered, setIsHovered] = useState(false);
  return (
    <>
      <button
        className="outline-button"
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
      >
        {content} <img src={!isHovered ? img : dimg} alt="" />
      </button>
    </>
  );
}
