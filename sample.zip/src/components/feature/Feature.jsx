import "./Feature.scss";
import bottomimg from "../../assets/images/Rectangle 16.png";
import earbud from "../../assets/images/earbuds.png";
import Button from "../reusables/Button";
import glass from "../../assets/images/Glasses.png";
import dglass from "../../assets/images/Glasses (1).png";
import FeatureBoxContainer from "./FeatureBoxContainer";
import data from "../../assets/data/feature.json";
import { useState } from "react";

export default function Feature() {
  const [content] = useState(data);
  const [currentIndex, setCurrentIndex] = useState(0);
  const changeIndex = (value) => {
    setCurrentIndex(value);
  };
  return (
    <div className="feature-tot-cont">
      <p className="head-content feature-head">Revolutionary Features </p>

      <FeatureBoxContainer changeIndex={changeIndex} />
    

      <div className="earbud-cont">
        <img src={earbud} alt="" />
      </div>
      <div className="feature-cont">
        <p className="small-head-content">{content[currentIndex]?.title}</p>
        <p className="h2-content">{content[currentIndex]?.description}</p>
        <div className="feature-btn">
          <Button content="WATCH THE REVEAL" img={glass} dimg={dglass} />
        </div>
      </div>

      <div className="bottom-img-cont">
        <img src={bottomimg} alt="" />
      </div>
    </div>
  );
}
